import { addMember, getMember, listMembers, pay, suspendMember, unsuspendMember } from "../../services/members.js"
import { activeLoans } from "../../services/loans.js"
import { publicMember } from "../../models/member.js"
import { publicLoan } from "../../models/loan.js"
import { AppError } from "../../utils/errors.js"

export function memberRoutes(router) {
  router.get("/members", () => listMembers().map(publicMember))

  router.get("/members/:id", ({ params }) => {
    const member = getMember(params.id)
    return { ...publicMember(member), loans: activeLoans(member.id).map(publicLoan), suspended: member.suspended }
  })

  router.post("/members", ({ body }) => ({ status: 201, body: publicMember(addMember(body)) }))

  router.post("/members/:id/payments", ({ params, body }) => {
    const amount = Number(body.amount)
    if (!(amount > 0)) throw new AppError("amount must be a positive number")
    return publicMember(pay(params.id, amount))
  })

  router.post("/members/:id/suspend", ({ params }) => {
    suspendMember(params.id)
    return { status: 204, body: null }
  })

  router.post("/members/:id/unsuspend", ({ params }) => {
    unsuspendMember(params.id)
    return { status: 204, body: null }
  })
}

