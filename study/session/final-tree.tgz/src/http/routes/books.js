import { addBook, getBook, retireBook, search, availableCopies } from "../../services/catalog.js"
import { publicBook } from "../../models/book.js"
import { optionalInt } from "../../utils/validate.js"
import { rateBook, getRatingsStats } from "../../services/ratings.js"

export function bookRoutes(router) {
  router.get("/books", ({ query }) =>
    search({
      q: query.q,
      genre: query.genre,
      available: query.available === undefined ? undefined : query.available === "true",
      from: optionalInt(query.from, "from", { min: 1000, max: 2100 }),
      to: optionalInt(query.to, "to", { min: 1000, max: 2100 }),
      page: optionalInt(query.page, "page", { min: 1 }) ?? 1,
    }),
  )

  router.get("/books/:id", ({ params }) => {
    const book = getBook(params.id)
    const base = publicBook(book, { available: availableCopies(book.id) > 0 })
    const { average, count } = getRatingsStats(book.id)
    return {
      ...base,
      averageRating: average,
      ratingsCount: count,
    }
  })

  router.post("/books/:id/ratings", ({ params, body }) => {
    const { memberId, stars } = body
    if (!memberId || typeof stars !== "number") return { status: 400, body: { error: "memberId and stars are required" } }
    try {
      rateBook(params.id, memberId, stars)
      return { status: 201, body: null }
    } catch (err) {
      return { status: 400, body: { error: err.message } }
    }
  })

  router.post("/books", ({ body }) => ({ status: 201, body: publicBook(addBook(body)) }))

  router.delete("/books/:id", ({ params }) => {
    retireBook(params.id)
    return { status: 204, body: null }
  })
}
