import * as store from "../db/store.js"
import { NotFoundError } from "../utils/errors.js"

export function rateBook(bookId, memberId, stars) {
  if (stars < 1 || stars > 5) throw new RangeError("stars must be between 1 and 5")

  // Compose rating id as 'bookId|memberId' to allow easy lookups
  const ratingId = `${bookId}|${memberId}`
  const rating = { id: ratingId, bookId, memberId, stars }

  // Add or update the rating
  store.insert("ratings", rating)
  return rating
}

export function getRatingsStats(bookId) {
  const ratings = store.where("ratings", (r) => r.bookId === bookId)
  if (ratings.length === 0) return { average: null, count: 0 }

  const sum = ratings.reduce((acc, r) => acc + r.stars, 0)
  const average = Math.round((sum / ratings.length) * 10) / 10

  return { average, count: ratings.length }
}
