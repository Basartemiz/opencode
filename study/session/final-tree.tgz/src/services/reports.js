import * as store from "../db/store.js"
import { getBook } from "./catalog.js"

export function getPopularBooks(limit = 5) {
  const borrowCounts = new Map()
  for (const loan of store.all("loans")) {
    borrowCounts.set(loan.bookId, (borrowCounts.get(loan.bookId) ?? 0) + 1)
  }
  const popular = [...borrowCounts.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([bookId, count]) => ({ book: getBook(bookId), borrowCount: count }))
  return popular
}
